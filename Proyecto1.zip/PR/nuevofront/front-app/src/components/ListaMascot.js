import React from 'react';

const ListaMascotas = ({mascota, setMascota, mascots, setListUpdated}) => {


    const handleDelete = id => {
        const requestInit = {
            method: 'DELETE'
        }
        fetch('http://localhost:9000/api/' + id, requestInit)
        .then(res => res.text())
        .then(res => console.log(res))

        setListUpdated(true)
    }

    let{pet, propietario, sintomas} = mascota
    const handleUpdate = id => {
        
        //validación de los datos
        if (pet === '' || propietario === '' || sintomas === '') {
            alert('Todos los campos son obligatorios')
            return
        }
        const requestInit = {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(mascota)
        }
        fetch('http://localhost:9000/api/' + id, requestInit)
        .then(res => res.text())
        .then(res => console.log(res))

        //reiniciando state de mascota
        setMascota({
            pet: '',
            propietario: '',
            sintomas: ''
        })

        setListUpdated(true)
    }


    return ( 
        <table className="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Mascota</th>
                    <th>Propietario</th>
                    <th>Sintomas</th>
                </tr>
            </thead>
            <tbody>
                {mascots.map (mascota => (
                    <tr key={mascota.id}>
                        <td>{mascota.id}</td>
                        <td>{mascota.pet}</td>
                        <td>{mascota.propietario}</td>
                        <td>{mascota.sintomas}</td>
                        <td>
                            <div className="mb-3">
                                <button onClick={() => handleDelete(mascota.id)} className="btn btn-danger">Borrar</button>
                            </div>
                            <div className="mb-3">
                                <button onClick={() => handleUpdate(mascota.id)} className="btn btn-dark">Actualizar</button>
                            </div>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
}
export default ListaMascotas;