import React from 'react';

const Form = ({mascota, setMascota}) => {

    const handleChange = e => {
        setMascota({
            ...mascota,
            [e.target.name]: e.target.value
        })
    }

    let{pet, propietario, sintomas} = mascota

    const handleSubmit = () => {
        
        //validación de los datos
        if (pet === '' || propietario === '' || sintomas === '' ) {
            alert('Todos los campos son obligatorios')
            return
        }

        //consulta
        const requestInit = {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(mascota)
        }
        fetch('http://localhost:9000/api', requestInit)
        .then(res => res.text())
        .then(res => console.log(res))
        
        //reiniciando state de mascotas
        setMascota({
            pet: '',
            propietario: '',
            sintomas: '',
        })



    }

    return ( 
        <form onSubmit={handleSubmit}>
            <div className="mb-3">
                <label htmlFor="mascotas" className="form-label">Mascota</label>
                <input value={pet} name="pet" onChange={handleChange} type="text" id="mascotas" className="form-control"/>
            </div>
            <div className="mb-3">
                <label htmlFor="propietario" className="form-label">Propietario</label>
                <input value={propietario} name="propietario" onChange={handleChange} type="text" id="propietario" className="form-control"/>
            </div>
            <div className="mb-3">
                <label htmlFor="sintomas" className="form-label">Sintomas</label>
                <input value={sintomas}  name="sintomas" onChange={handleChange} type="text" id="sintomas" className="form-control"/>
            </div>
            <button type="submit" className="btn btn-primary">Añadir</button>
        </form>
    );
}
 
export default Form;