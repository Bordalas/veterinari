import React, {Fragment, useState, useEffect} from 'react';
import Navbar from './components/Navbar.js';
import ListaMascotas from './components/ListaMascot.js';
import Form from './components/Form.js';

function App() {

  const [mascota, setMascota] = useState({
    pet: '',
    propietario: '',
    sintomas: '',
  })

  const [mascots, setMascots] = useState([])

  const [listUpdated, setListUpdated] = useState(false)

  useEffect(() => {
    const getMascotas = () => {
      fetch('http://localhost:9000/api')
      .then(res => res.json())
      .then(res => setMascots(res))
    }
    getMascotas()
    setListUpdated(false)
  }, [listUpdated])

  return (
    <Fragment>
      <Navbar brand='Veterinario'/>
      <div className="container">
        <div className="row">
          <div className="col-7">
            <h2 style={{textAlign: 'center'}}>Lista de mascotas</h2>
            <ListaMascotas mascots={mascots} mascota={mascota} setMascota={setMascota}  setListUpdated={setListUpdated}/>
          </div>
          <div className="col-5">
            <h2 style={{textAlign: 'center'}}>Fomulario Mascota</h2>
            <Form mascota={mascota} setMascota={setMascota}/>
          </div>
        </div>
      </div>
    </Fragment>
  );
}

export default App;


